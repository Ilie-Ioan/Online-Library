package ro.OnlineLibrary.OnlineLibraryApi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineLibraryApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineLibraryApiApplication.class, args);
	}

}
