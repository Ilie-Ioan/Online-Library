package OnlineLibrary.ro.MyApiApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyApiAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyApiAppApplication.class, args);
	}

}
